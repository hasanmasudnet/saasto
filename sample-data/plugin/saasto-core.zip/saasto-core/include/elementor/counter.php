<?php
namespace SaastoCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Saasto Core
 *
 * Elementor widget for Headings
 *
 * @since 1.0.0
 */
class Saasto_counter extends \Elementor\Widget_Base {
    
	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'saasto-counter';
	}
    
	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Counter', 'saastocore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'saasto-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saastocore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'saastocore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        /**
         * 
         * Start control for content tab
         */
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Icon Box', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        // Icon field
        $this->add_control(
			'counter_icon',
			[
				'label' => esc_html__( 'Icon', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-circle',
					'library' => 'fa-solid',
				]
			]
		);
        $this->add_control(
			'counter_title',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'Title', 'textdomain' ),
				'placeholder' => esc_html__( 'Enter your title', 'textdomain' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
			]
		);
		$this->add_control(
			'counter_end_number',
			[
				'type' => Controls_Manager::NUMBER,
				'label' => esc_html__( 'Ending Number', 'textdomain' ),
                'default' => '250',
                'dynamic' => [
                    'active' => true,
                ],
			]
		);
		// Counter Number prefix
		$this->add_control(
			'counter_num_prefix',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'Number Prefix', 'textdomain' ),
				'placeholder' => esc_html__( '1', 'textdomain' ),
                'dynamic' => [
                    'active' => true,
                ],
			]
		);
		// Counter Number Suffix 
		$this->add_control(
			'counter_num_suffix',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'Number Suffix', 'textdomain' ),
				'placeholder' => esc_html__( 'Plus', 'textdomain' ),
                'dynamic' => [
                    'active' => true,
                ],
			]
		);

        $this->end_controls_section();
        //End control for content tab


	/**
	 * 
	 * Start control for Style tab
	 */
	//Shape style tab start
	$this->start_controls_section(
			'icon_style',
			[
				'label' => esc_html__( 'Icon', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		 // Inner tabs
		 $this->start_controls_tabs(
            'style_tabs'
        );
        
			/** icon_style_normal start */
			$this->start_controls_tab(
				'icon_style_normal',
				[
					'label' => esc_html__( 'Normal', 'textdomain' ),
				]
			);

			// Count Icon BG
			$this->add_control(
				'icon_background',
				[
					'label' => esc_html__( 'Background', 'textdomain' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fact-icon' => 'background: {{VALUE}}',
					],
				]
			);
			// Count Icon BG
			$this->add_control(
				'icon_color',
				[
					'label' => esc_html__( 'Color', 'textdomain' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-fact:hover .fact-icon' => 'background: {{VALUE}}',
					],
				]
			);

			$this->end_controls_tab();
			/** icon_style_normal end */


			/** icon_style_hover start */
			$this->start_controls_tab(
				'icon_style_hover',
				[
					'label' => esc_html__( 'Hover', 'textdomain' ),
				]
			);

			// Count Icon BG
			$this->add_control(
				'icon_backgroundHover',
				[
					'label' => esc_html__( 'Background', 'textdomain' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-fact:hover .fact-icon' => 'background: {{VALUE}}',
					],
				]
			);
			// Count Icon color
			$this->add_control(
				'icon_colorHover',
				[
					'label' => esc_html__( 'Color', 'textdomain' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .your-class' => 'color: {{VALUE}}',
					],
				]
			);

			$this->end_controls_tab();
			/** icon_style_hover End */

		$this->end_controls_tab();
        // Inner tab end



        $this->end_controls_section();
        // Icons style tab End 

		//Number style tab start
		$this->start_controls_section(
			'number_style',
			[
				'label' => esc_html__( 'Icon', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			// Count number
			$this->add_control(
				'counter_number',
				[
					'label' => esc_html__( 'Number', 'textdomain' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .your-class' => 'color: {{VALUE}}',
					],
				]
			);

			// counter typography
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'counterNum_typog',
					'selector' => '{{WRAPPER}} .section-title .saasto-heading',
					
				]
			);

		$this->end_controls_section();
        // Number style tab End 


		//Number style tab start
		$this->start_controls_section(
			'counter_title_sec',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			// Counter Title color
			$this->add_control(
				'counter_title_color',
				[
					'label' => esc_html__( 'Color', 'textdomain' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fact-disc p' => 'color: {{VALUE}}',
					],
				]
			);

			// counter typography
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'count_headings_typog',
					'selector' => '{{WRAPPER}} .fact-disc p',
					
				]
			);

		$this->end_controls_section();
        // Number style tab End 

	}

    	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display(); 
		$id = $this->get_id();
		$this->add_render_attribute(
			'wrapper',
			[
				'id'	=> 'counter-'.$id,
				'class' => [ 'single-fact'],
			]
		);
		$this->add_render_attribute(
			'odometer',
			[
				'class' => [ 'odometer'],
				'data-odometer-final' => $settings['counter_end_number'],
			]
		);

		$counter_num_suffix = $settings['counter_num_suffix'] ? '<span class="counter-sp">'.$settings['counter_num_suffix'].'</span>' : '';
		$counter_num_prefix = $settings['counter_num_prefix'] ? '<span class="counter-sp">'.$settings['counter_num_prefix'].'</span>' : '';

		echo '<div '.$this->get_render_attribute_string('wrapper').'>';
		echo '<div class="fact-icon counter-item">';
		 \Elementor\Icons_Manager::render_icon( $settings['counter_icon'], [ 'aria-hidden' => 'true' ] ); 
		echo '</div>';
		echo '<div class="fact-disc position-relative">';
		printf('%3$s<h2 %1$s></h2>%2$s',$this->get_render_attribute_string('odometer'), $counter_num_suffix , $counter_num_prefix );
		echo '<p>'. esc_html( $settings['counter_title'] ) .'</p>';
		echo '</div>';
		echo '</div>';
    }
	
}

$widgets_manager->register( new Saasto_counter() );