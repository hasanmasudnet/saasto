<?php

if ( !defined( 'ABSPATH' ) ) {
    exit;
}

class Saasto_OCDI_Demo_Importer {

    public function __construct() {
        add_filter( 'pt-ocdi/import_files', [$this, 'import_files_config'] );
        add_filter( 'pt-ocdi/after_import', [$this, 'ocdi_after_import_setup'] );
        add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );
        add_action( 'init', [$this, 'Saasto_ocdi_rewrite_flush'] );
        add_action( 'ocdi/after_import', [$this, 'add_elementor_support']);

    }

    public function import_files_config() {

		$home_prevs = array(
			'saasto_demo_home_1' => array(
				'title' => __( 'Home 1', 'saastocore' ),
				'page'  => __( 'home', 'saastocore' ),
				'screenshot' => plugins_url( 'assets/img/demo/home-1.png', dirname(__FILE__) ),
				'preview_link' => '#',
			),
			'saasto_demo_home_2' => array(
				'title' => __( 'Home 2', 'saastocore' ),
				'page'  => __( 'home-two', 'saastocore' ),
				'screenshot' => plugins_url( 'assets/img/demo/home-2.png', dirname(__FILE__) ),
				'preview_link' => '#',
			),
            'saasto_demo_home_3' => array(
                'title' => __( 'Home 3', 'saastocore' ),
                'page'  => __( 'home-three', 'saastocore' ),
                'screenshot' => plugins_url( 'assets/img/demo/home-3.png', dirname(__FILE__) ),
                'preview_link' => '#',
            ),
		);

        $config = [];

        $import_path = trailingslashit( get_template_directory() ) . 'sample-data/';

        foreach ( $home_prevs as $key => $prev ) {

            $contents_demo = $import_path . 'contents-demo.xml';
            $widget_settings = $import_path . 'widget-settings.wie';
            $customizer_data = $import_path . 'customizer-data.dat';

            $config[] = [
                'import_file_id'               => $key,
                'import_page_name'             => $prev['page'],
                'import_file_name'             => $prev['title'],
                'local_import_file'            => $contents_demo,
                'local_import_widget_file'     => $widget_settings,
                'local_import_customizer_file' => $customizer_data,
                'import_preview_image_url'     => $prev['screenshot'],
                'preview_url'                  => $prev['preview_link'],
                'import_notice'                => esc_html__( 'After you import this demo, you will have to setup the slider separately.', 'saastocore' ),
            ];
        }

        return $config;
    }

    public function ocdi_after_import_setup( $selected_file ) {

        // $this->assign_menu_to_location();
        // assign the menu
        $main_menus = get_term_by( 'name', 'Main Menu', 'nav_menu' );

        set_theme_mod( 'nav_menu_locations', [
            'main-menu' => $main_menus->term_id,
        ] );

        $this->assign_frontpage_id( $selected_file );
        print_r($selected_file);
        
        $this->update_permalinks();
        update_option( 'basa_ocdi_importer_flash', true );
        exit;
    }

    // private function assign_menu_to_location() {

    //     $main_menus = get_term_by( 'name', 'Main Menu', 'nav_menu' );

    //     set_theme_mod( 'nav_menu_locations', [
    //         'main-menu' => $main_menus->term_id,
    //     ] );
    // }

    private function assign_frontpage_id( $selected_import ) {

        $front_page = get_page_by_title( $selected_import['import_page_name'] );
        $blog_page = get_page_by_title( 'Blog' );

        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', $front_page->ID );
        update_option( 'page_for_posts', $blog_page->ID );
    }

    private function update_permalinks() {
        update_option( 'permalink_structure', '/%postname%/' );
    }

    public function Saasto_ocdi_rewrite_flush() {

        if ( get_option( 'basa_ocdi_importer_flash' ) == true ) {
            flush_rewrite_rules();
            delete_option( 'basa_ocdi_importer_flash' );
        }
    }
    // add_action( 'elementor/init', [$this, 'add_elementor_support']);
	 public function add_elementor_support(){
		if ( class_exists( 'Elementor\Plugin' ) ) {
			return \Elementor\Plugin\Post_Type::instance()->add_support( 'saasto-templates' );
		} 
	 }

    //  public function import_elementor_site_settings(){
    //     $manager = Elementor\Core\Settings\Manager::instance();
    //     $file_path_1 = '/path/to/your/settings_1.json';
    //     $file_path_2 = '/path/to/your/settings_2.json';
    //     $manager->import_settings( $file_path_1 );
    //     $manager->import_settings( $file_path_2 );
    //  }
   

}

new Saasto_OCDI_Demo_Importer;
