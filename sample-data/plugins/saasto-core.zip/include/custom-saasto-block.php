<?php 
class SaastoblocksPost 
{
	function __construct() {
		add_action( 'init', array( $this, 'register_custom_post_type' ) );
		add_filter( 'template_include', array( $this, 'saasto_block_include' ) );

		// Add new column to saasto-block post type
		add_filter('manage_saasto-blocks_posts_columns', [$this, 'saasto_blocks_columns']);
		// Populate the new column with shortcode data
		add_action('manage_saasto-blocks_posts_custom_column', [$this, 'saasto_blocks_shortcode'], 10, 2);

		// init shortocde
		add_shortcode( 'saasto-block', [$this, 'saasto_shortcode_blocks'] );
	}
	
	public function saasto_block_include( $template ) {
		if ( is_singular( 'saasto-blocks' ) ) {
			return $this->get_template( 'single-saasto-block.php');
		}
		return $template;
	}
	
	
	public function get_template( $template ) {
		if ( $theme_file = locate_template( array( $template ) ) ) {
			$file = $theme_file;
		} 
		else {
			$file = SAASTOCORE_ADDONS_DIR . '/include/template/'. $template;
		}
		return apply_filters( __FUNCTION__, $file, $template );
	}
	
	
	public function register_custom_post_type() { 
		$labels = array(
			'name'                  => esc_html_x( 'Saasto Block', 'Post Type General Name', 'saastocore' ),
			'singular_name'         => esc_html_x( 'Saasto Block', 'Post Type Singular Name', 'saastocore' ),
			'menu_name'             => esc_html__( 'Saasto Blocks', 'saastocore' ),
			'name_admin_bar'        => esc_html__( 'Saasto Block', 'saastocore' ),
			'archives'              => esc_html__( 'Item Archives', 'saastocore' ),
			'parent_item_colon'     => esc_html__( 'Parent Item:', 'saastocore' ),
			'all_items'             => esc_html__( 'All Items', 'saastocore' ),
			'add_new_item'          => esc_html__( 'Add New Blocks', 'saastocore' ),
			'add_new'               => esc_html__( 'Add New', 'saastocore' ),
			'new_item'              => esc_html__( 'New Item', 'saastocore' ),
			'edit_item'             => esc_html__( 'Edit Item', 'saastocore' ),
			'update_item'           => esc_html__( 'Update Item', 'saastocore' ),
			'view_item'             => esc_html__( 'View Item', 'saastocore' ),
			'search_items'          => esc_html__( 'Search Item', 'saastocore' ),
			'not_found'             => esc_html__( 'Not found', 'saastocore' ),
			'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'saastocore' ),
			'featured_image'        => esc_html__( 'Featured Image', 'saastocore' ),
			'set_featured_image'    => esc_html__( 'Set featured image', 'saastocore' ),
			'remove_featured_image' => esc_html__( 'Remove featured image', 'saastocore' ),
			'use_featured_image'    => esc_html__( 'Use as featured image', 'saastocore' ),
			'inserbt_into_item'     => esc_html__( 'Insert into item', 'saastocore' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'saastocore' ),
			'items_list'            => esc_html__( 'Items list', 'saastocore' ),
			'items_list_navigation' => esc_html__( 'Items list navigation', 'saastocore' ),
			'filter_items_list'     => esc_html__( 'Filter items list', 'saastocore' ),
		);

		$args   = array(
			'label'                 => esc_html__( 'Saasto Block', 'saastocore' ),
			'labels'                => $labels,
			'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail'),
			'hierarchical'          => false,
			'public'                => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => 5,
			'menu_icon'   			=> 'dashicons-smiley',
			'show_in_admin_bar'     => true,
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => true,		
			'exclude_from_search'   => false,
			'publicly_queryable'    => true,
			'capability_type'       => 'page',
		);

		register_post_type( 'saasto-blocks', $args );
	}

	public function saasto_blocks_columns($columns) {
		// Move the Date column to a variable and remove it from the array
		$date = $columns['date'];
		unset($columns['date']);
		
		// Add the Shortcode column before the Date column
		$columns['shortcode'] = __('Shortcode');
		$columns['date'] = $date; // Add the Date column back to the array
		return $columns;
	}

	public function saasto_blocks_shortcode($column, $post_id) {
		if ($column === 'shortcode') {
			echo "<input  type='text' value='[saasto-block id=\"{$post_id}\"]' disabled style='color:#000'>";
		}
	}

	public function saasto_shortcode_blocks( $atts ){

		$data = shortcode_atts( array(
			'id' => '',
		), $atts );

		$post_id = $data['id'];

		echo Elementor\Plugin::instance()->frontend->get_builder_content($post_id);

	}
	
}

new SaastoblocksPost();
