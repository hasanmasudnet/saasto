<?php
namespace SaastoCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Saasto Core
 *
 * Elementor widget for Headings
 *
 * @since 1.0.0
 */
class Saasto_button extends \Elementor\Widget_Base {
    
	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'saasto-button';
	}
    
	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Button', 'saastocore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'saasto-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saastocore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'saastocore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        /**
         * 
         * Start control for content tab
         */

        //  Widget Layout Area
        $this->start_controls_section(
			'layout_section',
			[
				'label' => esc_html__( 'Layout', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'btn_style',
			[
				'type'      => \Elementor\Controls_Manager::SELECT,
				'label'     => esc_html__( 'Style', 'textdomain' ),
				'options'   => [
                        'one'   => esc_html__( 'Style 1', 'textdomain' ),
                        'two'   => esc_html__( 'Style 2', 'textdomain' ),
                        'three' => esc_html__( 'Style 3', 'textdomain' ),
                        'four'  => esc_html__( 'Style 4', 'textdomain' ),
                    ],
				'default' => 'one',
                'separator' => 'after'
			]
		);

        $this->add_control(
			'btn_align',
			[
				'label' => esc_html__( 'Alignment', 'textdomain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'textdomain' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'textdomain' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'textdomain' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

        $this->add_control(
			'btn_icon',
			[
				'label' => esc_html__( 'Icon', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fab fa-microsoft',
					'library' => 'fa-brands',
				],
			]
		);


        $this->end_controls_section();
        //End control for content tab

        // Widget Content Area
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'btn_text',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'Text', 'textdomain' ),
				'placeholder' => esc_html__( 'Get Started Now', 'textdomain' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
                'default' => 'Get Started Now'
			]
		);
        $this->add_control(
			'btn_top_text',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'Sub Text', 'textdomain' ),
				'placeholder' => esc_html__( 'GET IT NOW', 'textdomain' ),
                'dynamic' => [
                    'active' => true,
                ],
                'default' => 'GET IT NOW',
                'condition' => [
                    'btn_style' => 'four',
                ],
			]
		);

        $this->add_control(
			'btn_link',
			[
				'label' => esc_html__( 'Link', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'textdomain' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
					'is_external' => false,
					'nofollow' => false,
				],
				'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
			]
		);

        $this->end_controls_section();
        //End control for content tab


        /**
         * 
         * Start control for Style tab
         */
		 //Shape style tab start
		$this->start_controls_section(
			'btn_style_content',
			[
				'label' => esc_html__( 'Style', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'headings_typography',
				'selector' => '{{WRAPPER}} .saasto-btn',
				
			]
		);

        // Inner tabs
		$this->start_controls_tabs(
            'style_tabs'
        );
        
        // Inner tab start
        $this->start_controls_tab(
            'btn_style_normal',
            [
                'label' => esc_html__( 'Normal', 'textdomain' ),
            ]
        );
        
        $this->add_control(
			'btn_bg',
			[
				'label' => esc_html__( 'Background', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .saasto-btn' => 'background: {{VALUE}}',
				],
				'default' => '#8976fd'
			]
		);

        $this->add_control(
			'btn_txt_color',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .saasto-btn' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'btn_border',
				'selector' => '{{WRAPPER}} .saasto-btn',
			]
		);
       
        $this->end_controls_tab();
        // Inner tab end

        // Inner tab start
        $this->start_controls_tab(
            'btn_style_hover',
            [
                'label' => esc_html__( 'Hover', 'textdomain' ),
            ]
        );

        $this->add_control(
			'btn_bg_hover',
			[
				'label' => esc_html__( 'Background', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .saasto-btn:hover' => 'background: {{VALUE}}',
				],
				'default' => '#8976fd'
			]
		);

		$this->add_control(
			'btn_shap_hover_s2',
			[
				'label' => esc_html__( 'Background', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .saasto-btn.btn-fill-pill::before, {{WRAPPER}} .saasto-btn.btn-fill-pill::after, {{WRAPPER}} .saasto-btn.btn-fill-pill span' => 'background: {{VALUE}}',
				],
				'condition' => [
					'btn_style' => 'two'
				]
			]
		);

        $this->add_control(
			'btn_txt_color_hover',
			[
				'label' => esc_html__( 'Text Color', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .saasto-btn:hover' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);
        
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'btn_border_hover',
				'selector' => '{{WRAPPER}} .saasto-btn',
			]
		);

        $this->end_controls_tab();
        // Inner tab end
        $this->end_controls_tabs();
        // Inner tab wrapper

        $this->add_control(
			'btn_padding',
			[
				'label' => esc_html__( 'Padding', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .saasto-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
        $this->end_controls_section();
		 //Shape style tab End


	}

    	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

        if('one' == $settings['btn_style']){

            // attribute for style one
            $this->add_render_attribute(
                'btn_attr',
                [
                    'class' => [ 'saasto-btn btn-fill-rounded'],
					'href'	=> $settings['btn_link']['url'],
					'target' => $settings['btn_link']['is_external'],
                ]
            );
        }elseif('two' == $settings['btn_style']){

            // attribute for style two
            $this->add_render_attribute(
                'btn_attr',
                [
                    'class' => [ 'saasto-btn btn-fill-pill'],
					'href'	=> $settings['btn_link']['url'],
					'target' => $settings['btn_link']['is_external'],
                ]
            );

        }elseif('three' == $settings['btn_style']){

            // attribute for style three
            $this->add_render_attribute(
                'btn_attr',
                [
                    'class' => [ 'saasto-btn btn-fill-outlined'],
					'href'	=> $settings['btn_link']['url'],
					'target' => $settings['btn_link']['is_external'],
                ]
            );
        }elseif('four' == $settings['btn_style']){

            // attribute for style four
            $this->add_render_attribute(
                'btn_attr',
                [
                    'class' => [ 'saasto-btn download-btn-outlined'],
					'href'	=> $settings['btn_link']['url'],
					'target' => $settings['btn_link']['is_external'],
                ]
            );
        }

		// Show this markup for one, two, three btn style
		if('four' != $settings['btn_style']){
			$span_tag = ('two' == $settings['btn_style']) ? '<span></span>' : '';
			$icon = ($settings['btn_icon']['value']) ? '<i class="'. $settings['btn_icon']['value'].'"></i>' : '';

			printf('<a %1$s >%2$s %3$s%4$s</a>', $this->get_render_attribute_string( 'btn_attr' ), saastoCore_kses($settings['btn_text']), $span_tag, $icon);
		}
		// Show this markup for only four btn style
		else{
			$icon = ($settings['btn_icon']['value']) ? '<i class="'. $settings['btn_icon']['value'].'"></i>' : '';
			$sub_txt = ($settings['btn_top_text']) ? '<span>'.$settings['btn_top_text'].'</span>' : '';
			printf('<a %1$s >%2$s<div>%3$s<h5>%4$s</h5></div></a>', $this->get_render_attribute_string( 'btn_attr' ),$icon , $sub_txt, saastoCore_kses($settings['btn_text']));
			
		}
    }
	
}

$widgets_manager->register( new Saasto_button() );

