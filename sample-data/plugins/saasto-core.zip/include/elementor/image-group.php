<?php
namespace SaastoCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Saasto Core
 *
 * Elementor widget for Headings
 *
 * @since 1.0.0
 */
class Saasto_imageGroup extends \Elementor\Widget_Base {
    
	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'saasto-image-group';
	}
    
	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Image group', 'saastocore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'saasto-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saastocore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'saastocore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        /**
         * 
         * Start control for content tab
         */
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Headline', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

       
        $this->end_controls_section();
        //End control for content tab


        /**
         * 
         * Start control for Style tab
         */
		 //Shape style tab start
		$this->start_controls_section(
			'shape_style',
			[
				'label' => esc_html__( 'Shape', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
			// Inner tabs
			$this->start_controls_tabs(
				'style_tabs'
			);

				/** icon_style_normal start */
				$this->start_controls_tab(
					'icon_style_normal',
					[
						'label' => esc_html__( 'Normal', 'textdomain' ),
					]
				);

				// Count Icon BG
				$this->add_control(
					'icon_background',
					[
						'label' => esc_html__( 'Background', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .your-class' => 'color: {{VALUE}}',
						],
					]
				);

				$this->end_controls_tab();
				/** icon_style_normal end */


				/** icon_style_hover start */
				$this->start_controls_tab(
					'icon_style_hover',
					[
						'label' => esc_html__( 'Hover', 'textdomain' ),
					]
				);

				// Count Icon BG
				$this->add_control(
					'icon_backgroundHover',
					[
						'label' => esc_html__( 'Text Color', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .your-class' => 'color: {{VALUE}}',
						],
					]
				);

				$this->end_controls_tab();
				/** icon_style_hover End */

			$this->end_controls_tab();
			// Inner tab end

        $this->end_controls_section();
        //End control for content tab
	}

    	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display(); ?>

	<div class="hero-florting-col position-absolute end-0 top-50 translate-middle-y pt-0 pt-lg-5 mt-4">
		<img src="<?php echo get_template_directory_uri() ?>/assets/img/shapes/hero-line-vactor.svg" alt="" class="hero-line-vactor d-xl-block d-none">
		<img src="<?php echo get_template_directory_uri() ?>/assets/img/shapes/hero-carve.png" alt="" class="d-xl-block d-none position-absolute top-50 end-0 translate-middle-y">
		<div class="row justify-content-center">
			<div class="col-lg-12 col-8 text-center">
				<img src="<?php echo get_template_directory_uri() ?>/assets/img/hero/hero-graph-2.png" alt=""  class="hero-img-filter img-fluid anima-trasform-y-1">
			</div>

		</div>
		<div class="item-row d-flex justify-content-center gap-xl-5 gap-4 mt-xl-5 mt-3">
			<img src="<?php echo get_template_directory_uri() ?>/assets/img/shapes/hero-dots.svg" alt="" class="position-absolute start-0 bottom-0">
			<div class="item">
				<img src="<?php echo get_template_directory_uri() ?>/assets/img/hero/hero-graph-1.png" alt="" class="hero-img-filter img-fluid anima-trasform-x-1">
			</div>
			<div class="d-inline-flex flex-column">
				<img src="<?php echo get_template_directory_uri() ?>/assets/img/hero/hero-graph-4.png" alt="" class="fit-content img-fluid">
				<img src="<?php echo get_template_directory_uri() ?>/assets/img/hero/hero-graph-3.png" alt="" class="hero-img-filter img-fluid mt-xl-5 mt-3 fit-content">
			</div>
		</div>
	</div

<?php

    }
	
}

$widgets_manager->register( new Saasto_imageGroup() );

