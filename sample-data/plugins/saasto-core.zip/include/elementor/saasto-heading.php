<?php
namespace SaastoCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Saasto Core
 *
 * Elementor widget for Headings
 *
 * @since 1.0.0
 */
class Saasto_Heading extends \Elementor\Widget_Base {
    
	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'saasto-heading';
	}
    
	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Heading', 'saastocore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'saasto-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saastocore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'saastocore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        /**
         * 
         * Start control for content tab
         */
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Headline', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'headline_select_shap',
			[
				'type' => \Elementor\Controls_Manager::SELECT,
				'label' => esc_html__( 'Shap', 'textdomain' ),
				'options' => [
					'normal' => esc_html__( 'Normal', 'textdomain' ),
					'underline' => esc_html__( 'Underline', 'textdomain' ),
					'circle' => esc_html__( 'circle', 'textdomain' ),
				],
				'default' => 'normal',
                'separator' => 'after'
			]
		);

        $this->add_control(
			'before_text',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'Before Text', 'textdomain' ),
				'placeholder' => esc_html__( 'Enter your title', 'textdomain' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
			]
		);
        $this->add_control(
			'highlighted_text',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'Highlighted Text', 'textdomain' ),
				'placeholder' => esc_html__( 'Enter your title', 'textdomain' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
			]
		);
        $this->add_control(
			'after_text',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'After Text', 'textdomain' ),
				'placeholder' => esc_html__( 'Enter your title', 'textdomain' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
			]
		);

		$this->add_control(
			'headline_description',
			[
				'type' => Controls_Manager::TEXTAREA,
				'label' => esc_html__( 'Description', 'textdomain' ),
				'placeholder' => esc_html__( 'Description', 'textdomain' ),
                'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
                'separator' => 'after'
			]
		);

        $this->add_control(
			'headline_align',
			[
				'label' => esc_html__( 'Alignment', 'textdomain' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'textdomain' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'textdomain' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'textdomain' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .section-title' => 'text-align: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'headline_html_tag',
            [
                'label' => esc_html__('HTML Tag', 'saastocore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => esc_html__('H1', 'saastocore'),
                    'h2' => esc_html__('H2', 'saastocore'),
                    'h3' => esc_html__('H3', 'saastocore'),
                    'h4' => esc_html__('H4', 'saastocore'),
                    'h5' => esc_html__('H5', 'saastocore'),
                    'h6' => esc_html__('H6', 'saastocore'),
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );
       
        $this->end_controls_section();
        //End control for content tab


        /**
         * 
         * Start control for Style tab
         */

		 //Shape style tab start
		$this->start_controls_section(
			'shape_style',
			[
				'label' => esc_html__( 'Shape', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
        $this->add_control(
			'headline_shapefill',
			[
				'label' => esc_html__( 'Fill', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title .saasto-heading svg' => 'fill: {{VALUE}}',
				],
				'default' => '#FF733B'
			]
		);

		$this->add_control(
			'headline_shapestroke',
			[
				'label' => esc_html__( 'Stroke', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title .saasto-heading svg' => 'stroke: {{VALUE}}',
				],
				'default' => '#FFD375'
			]
		);
		
        $this->add_control(
			'headline_shapetxtcolor',
			[
				'label' => esc_html__( 'Shape Text', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title .saasto-heading span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_section();
		 //Shape style tab End

        $this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Headline', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'headline_txt_color',
			[
				'label' => esc_html__( 'Shape Color', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title .saasto-heading' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'headings_typography',
				'selector' => '{{WRAPPER}} .section-title .saasto-heading',
				
			]
		);

		$this->add_control(
			'headline_description_color',
			[
				'label' => esc_html__( 'description Color', 'textdomain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
				],
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'selector' => '{{WRAPPER}} .section-title p',
			]
		);

        $this->end_controls_section();
        //End control for content tab
	}

    	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		// get headline select shap
		$shap_svg ='';
		if( 'underline' ==$settings['headline_select_shap'] ){
			$shap_svg = '<svg class="highlighter-shape position-absolute start-0 bottom-0 low-index" viewBox="0 0 176 35" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M0.728655 19.3058C2.19019 15.4551 7.67097 12.4868 10.2287 11.484C21.921 6.67064 40.7383 4.26372 48.594 5.46718C56.4498 6.67064 47.8633 9.07716 40.3729 11.4839C32.8825 13.8906 38.3633 15.094 45.1229 13.8906C51.8825 12.6872 65.9498 11.4839 78.0075 10.8822C90.0652 10.2805 77.8248 9.07716 65.9498 9.07716C54.0748 9.07716 54.2575 6.67054 58.4594 5.46718C62.6614 4.26381 72.1614 -0.54963 83.3056 0.0520504C94.4498 0.653731 120.758 1.85709 132.084 6.06886C143.411 10.2806 166.796 21.7126 172.46 25.3226C178.123 28.9327 177.392 39.1613 167.344 33.1445C157.296 27.1277 136.469 16.2974 90.796 14.4924C45.1229 12.6873 10.4113 22.9159 6.75748 27.1277C3.10363 31.3394 0.545936 31.3394 2.00748 27.7294C3.46902 24.1193 3.83443 23.5176 2.37289 24.721C0.911348 25.9243 -1.09827 24.1193 0.728655 19.3058Z" fill="#FF733B"/>
			</svg>';

		}elseif( 'circle' ==$settings['headline_select_shap'] ){
			$shap_svg = '<svg class="w-100 position-absolute start-50 top-50 translate-middle low-index d-none d-lg-block" viewBox="0 0 184 77" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M180.018 19.0935C158.348 9.2276 102.006 -6.33145 49.9974 10.3598C-15.0131 31.2238 -12.1108 65.1883 55.8019 72.4665C123.715 79.7446 189.885 59.8509 180.018 39.4722C170.152 19.0935 133.583 18.123 117.911 15.6969" stroke-width="5" stroke-linecap="round"/>
			</svg>';
			
		}else{
			// normal

		}

		if( !empty($settings['headline_before_text']) || !empty($settings['highlighted_text']) || !empty($settings['after_text'])){
			echo '<div class="section-title">';
			
			printf('<%5$s class="text-soft-black saasto-heading">%2$s <span class="d-inline-block position-relative"> %3$s %1$s</span>%4$s</%5$s>', $shap_svg, $settings['before_text'],$settings['highlighted_text'],$settings['after_text'], $settings['headline_html_tag'], );
			
			if( !empty( $settings['headline_description'] )){
				printf('<p>%s</p>',$settings['headline_description']);
			}
			echo '</div>';
		}
    }
	
}

$widgets_manager->register( new Saasto_Heading() );

