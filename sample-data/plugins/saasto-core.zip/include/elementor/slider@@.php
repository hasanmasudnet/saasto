<?php
namespace SaastoCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Saasto Core
 *
 * Elementor widget for Headings
 *
 * @since 1.0.0
 */
class Saasto_slider extends \Elementor\Widget_Base {
    
	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'saasto_slider';
	}
    
	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Slider', 'saastocore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'saasto-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saastocore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'saastocore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        /**
         * 
         * Start control for content tab
         */

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
        $this->end_controls_section();
		 // end control for content tab


	}

    	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() { ?>


  
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-3">
                    <div class="swiper testimonial-thumbs-two swiper-fade swiper-initialized swiper-horizontal swiper-pointer-events swiper-thumbs">
                        <div class="swiper-wrapper" id="swiper-wrapper-2a9d34ce6673bb74" aria-live="polite" style="transition-duration: 0ms;">
                            <div class="swiper-slide swiper-slide-prev" style="width: 261px; opacity: 0; transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;" role="group" aria-label="1 / 2">
                                <div class="testimonial-thumb-style-two">
                                    <img src="http://saasto.test/wp-content/themes/saasto-wp/assets/img/shapes/testi-thumb-man-1.png" alt="">
                                </div>
                            </div>
                            <div class="swiper-slide swiper-slide-thumb-active swiper-slide-visible swiper-slide-active" style="width: 261px; opacity: 1; transform: translate3d(-261px, 0px, 0px); transition-duration: 0ms;" role="group" aria-label="2 / 2">
                                <div class="testimonial-thumb-style-two">
                                    <img src="http://saasto.test/wp-content/themes/saasto-wp/assets/img/shapes/testi-thumb-man-1.png" alt="">
                                </div>
                            </div>
                        </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                </div>
                <div class="col-lg-7">
                    <div class="swiper testimonial-slider-two swiper-initialized swiper-horizontal swiper-pointer-events">
                        <div class="swiper-wrapper" id="swiper-wrapper-e9b91ef91ac5eec10" aria-live="polite" style="transition-duration: 0ms; transform: translate3d(-1330px, 0px, 0px);"><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="1" style="width: 641px; margin-right: 24px;" role="group" aria-label="2 / 2">
                                <div class="testimonial-card-style-two px-4">
                                    <p class="body-disply-2">Leading an organization is incredibly rewarding and equally humbling. Confidence and humility. Every success is built on lessons from mistakes made is incredibly rewarding</p>
                                    <div class="testimonial-card-bottom">
                                        <h5 class="reviewer-name">Mila McSabbu</h5>
                                        <span>Designer</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide swiper-slide-prev swiper-slide-duplicate-next" data-swiper-slide-index="0" style="width: 641px; margin-right: 24px;" role="group" aria-label="1 / 2">
                                <div class="testimonial-card-style-two px-4">
                                    <p class="body-disply-2">Leading an organization is incredibly rewarding and equally humbling. Confidence and humility. Every success is built on lessons from mistakes made is incredibly rewarding</p>
                                    <div class="testimonial-card-bottom">
                                        <h5 class="reviewer-name">Mila McSabbu</h5>
                                        <span>Designer</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="1" style="width: 641px; margin-right: 24px;" role="group" aria-label="2 / 2">
                                <div class="testimonial-card-style-two px-4">
                                    <p class="body-disply-2">Leading an organization is incredibly rewarding and equally humbling. Confidence and humility. Every success is built on lessons from mistakes made is incredibly rewarding</p>
                                    <div class="testimonial-card-bottom">
                                        <h5 class="reviewer-name">Mila McSabbu</h5>
                                        <span>Designer</span>
                                    </div>
                                </div>
                            </div>
                        <div class="swiper-slide swiper-slide-duplicate swiper-slide-next swiper-slide-duplicate-prev" data-swiper-slide-index="0" role="group" aria-label="1 / 2" style="width: 641px; margin-right: 24px;">
                                <div class="testimonial-card-style-two px-4">
                                    <p class="body-disply-2">Leading an organization is incredibly rewarding and equally humbling. Confidence and humility. Every success is built on lessons from mistakes made is incredibly rewarding</p>
                                    <div class="testimonial-card-bottom">
                                        <h5 class="reviewer-name">Mila McSabbu</h5>
                                        <span>Designer</span>
                                    </div>
                                </div>
                            </div></div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                    <div class="testi-pagination-two px-4 d-inline-flex pt-4 swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal"><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 1"></span><span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button" aria-label="Go to slide 2"></span></div>
                </div>
            </div>

<?php
    }
	
}

$widgets_manager->register( new Saasto_slider() );