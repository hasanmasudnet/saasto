<?php
namespace SaastoCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Responsive_Control;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Saasto Core
 *
 * Elementor widget for Headings
 *
 * @since 1.0.0
 */
class Saasto_blogPost extends \Elementor\Widget_Base {
    
	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'saasto_slider';
	}
    
	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Blog Slider', 'saastocore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'saasto-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saastocore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'saastocore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        /**
         * 
         * Start control for content tab
         */

        // Blog Layout 
        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'blog_skin',
			[
				'type'      => \Elementor\Controls_Manager::SELECT,
				'label'     => esc_html__( 'Skin', 'textdomain' ),
				'options'   => [
                        'one'   => esc_html__( 'Style 1', 'textdomain' ),
                    ],
				'default' => 'one',
			]
		);

        // $this->add_control(
		// 	'blog_slide_column',
		// 	[
		// 		'label' => esc_html__( 'Columns', 'textdomain' ),
		// 		'type' => \Elementor\Controls_Manager::SLIDER,
		// 		// 'size_units' => ['custom'],
		// 		'range' => [
        //             'px' => [
		// 				'min' => 1,
		// 				'max' => 10,
		// 				'step' => 1,
		// 			],
		// 		],
		// 		'default' => [
		// 			'size' => 3,
		// 		]
		// 	]
		// );


		$this->add_responsive_control(
			'control-name',
			[
				'label' => esc_html__( 'Spacing', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
			]
		);

		$this->add_responsive_control(
			'blog_slide_column',
			[
				'type' => \Elementor\Controls_Manager::SLIDER,
				'label' => esc_html__( 'Columns', 'textdomain' ),
				'range' => [
                    'px' => [
						'min' => 1,
						'max' => 10,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 3,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 3,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 2,
					'unit' => 'px',
				],
			]
		);

		$this->add_control(
			'slide_post_per_page',
			[
				'label' => esc_html__( 'Posts per page', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 5,
				'max' => 25,
				'default' => 8,
			]
		);
        $this->add_control(
			'slide_readmore',
			[
				'label' => esc_html__( 'Button', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Read more', 'textdomain' ),
				'placeholder' => esc_html__( 'Read more', 'textdomain' ),
                'separator' => 'after'
			]
		);
        $this->add_control(
			'meta_author',
			[
				'label' => esc_html__( 'Show Author', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
        $this->add_control(
			'meta_date',
			[
				'label' => esc_html__( 'Show Date', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
        $this->add_control(
			'meta_excerpt',
			[
				'label' => esc_html__( 'Excerpt', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				// 'return_value' => 'Hide',
				'default' => 'Hide',
			]
		);
        $this->add_control(
			'slide_arrow',
			[
				'label' => esc_html__( 'Navigation', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'Yes',
				'default' => 'Show',
			]
		);
		$this->add_control(
			'slide_auto_play',
			[
				'label' => esc_html__( 'Autoplay', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'textdomain' ),
				'label_off' => esc_html__( 'Hide', 'textdomain' ),
				'return_value' => 'Yes',
				'default' => 'Show',
			]
		);
		$this->add_control(
			'slide_auto_play_speed',
			[
				'label' => esc_html__( 'Autoplay', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1500,
				'condition' => [
					'slide_auto_play' => 'Yes'
				]
			]
		);

		$this->add_control(
			'slide_speed',
			[
				'label' => esc_html__( 'Slide Speed', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 1000,
			]
		);

        $this->add_control(
			'section_heading',
			[
				'label' => esc_html__( 'Heading', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'Most Popular Posts',
                'label_block' => true
			]
		);

        $this->end_controls_section();
		 // end control for content tab


	}

    /**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() { 
		$settings	= $this->get_settings_for_display();
		$widget_id	= $this->get_id();

		$blog_slider_settings = [
			'slider_wrapper' => $widget_id,
			'blog_slide_column' => $settings['blog_slide_column']['size'],
			'slide_arrow' => $settings['slide_arrow'],
			'slide_auto_play' => $settings['slide_auto_play'],
			'slide_auto_play_speed' => $settings['slide_auto_play_speed'],
			'slide_speed' => $settings['slide_speed'],
		];


		$this->add_render_attribute(
			'blog-slider-attr',
			[
				'class' => [ 'blog-style-one position-relative'],
				'data-blog-slide-settings'	=> json_encode($blog_slider_settings),
			]
		);
		print_r($settings['blog_slide_column']);
        ?>


<div <?php echo $this->get_render_attribute_string('blog-slider-attr') ?> >

        <div class="row align-content-center pt-60">
            <div class="col-md-7">
                <h4>Most popular posts</h4>
            </div>
            <div class="col-md-5 ">
                <div class="blog-slider-nav d-md-flex justify-content-end d-none">
                    <div class="blog-prev prev_<?php echo esc_attr( $widget_id ); ?>"><i class="bi bi-chevron-left"></i></div>
                    <div class="blog-next next_<?php echo esc_attr( $widget_id ); ?>"><i class="bi bi-chevron-right"></i></div>
                </div>
            </div>
        </div>

        <div class="swiper pt-5 <?php echo 'blog_slider_'. $widget_id; ?>">
            <div class="swiper-wrapper ">
                
                <div class="swiper-slide">
                    <div class="blog-card-style-one">
                        <div class="blog-thumb">
                            <a href="blog-details.html"><img src="assets/images/blog/blog-thumb-3.png" alt=""></a>
                        </div>
                        <div class="blog-disc">
                            <div class="blog-meta d-flex justify-content-between">
                                <a href="#">Random</a>
                                <a href="#">24 nov, 2021</a>
                            </div>
                            <h5 class="blog-title"><a href="blog-details.html">Weekly roundup SaaS global SaaS </a></h5>
                            <div class="blog-btn">
                                <a href="blog-details.html">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="swiper-slide">
                    <div class="blog-card-style-one">
                        <div class="blog-thumb">
                            <a href="blog-details.html"><img src="assets/images/blog/blog-thumb-3.png" alt=""></a>
                        </div>
                        <div class="blog-disc">
                            <div class="blog-meta d-flex justify-content-between">
                                <a href="#">Random</a>
                                <a href="#">24 nov, 2021</a>
                            </div>
                            <h5 class="blog-title"><a href="blog-details.html">Weekly roundup SaaS global SaaS </a></h5>
                            <div class="blog-btn">
                                <a href="blog-details.html">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="swiper-slide">
                    <div class="blog-card-style-one">
                        <div class="blog-thumb">
                            <a href="blog-details.html"><img src="assets/images/blog/blog-thumb-3.png" alt=""></a>
                        </div>
                        <div class="blog-disc">
                            <div class="blog-meta d-flex justify-content-between">
                                <a href="#">Random</a>
                                <a href="#">24 nov, 2021</a>
                            </div>
                            <h5 class="blog-title"><a href="blog-details.html">Weekly roundup SaaS global SaaS </a></h5>
                            <div class="blog-btn">
                                <a href="blog-details.html">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php
    }
	
}

$widgets_manager->register( new Saasto_blogPost() );