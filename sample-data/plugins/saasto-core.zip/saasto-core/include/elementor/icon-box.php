<?php
namespace SaastoCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Saasto Core
 *
 * Elementor widget for Headings
 *
 * @since 1.0.0
 */
class Saasto_iconBox extends \Elementor\Widget_Base {
    
	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'saasto-icon-box';
	}
    
	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Icon box', 'saastocore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'saasto-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saastocore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'saastocore' ];
	}


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        /**
         * 
         * Start control for content tab
         */

		// Layout icon box start
		$this->start_controls_section(
			'layout_section',
			[
				'label' => esc_html__( 'Layout', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'ic_layout_design',
			[
				'label' => esc_html__( 'Layout', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => [
					'' => esc_html__( 'Default', 'textdomain' ),
					'style1' 	=> esc_html__( 'Style 1', 'textdomain' ),
					'style2'  	=> esc_html__( 'Style 2', 'textdomain' ),
					'style3' 	=> esc_html__( 'Style 3', 'textdomain' ),
				],
				'default' => ''
			]
		);

		$this->end_controls_section();
        //End Layout icon box

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		/** Repeater Field start */
		$this->add_control(
			'icon_list',
			[
				'label' => esc_html__( 'Repeater List', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => [
					[
						'name' => 'ic_icon',
						'label' => esc_html__( 'Icon', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::ICONS,
						'default' => [
							'value' => 'fas fa-circle',
							'library' => 'fa-solid',
						],
					], 
					[
						'name' => 'ic_title',
						'label' => esc_html__( 'Title', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::TEXT,
						'default' => esc_html__( 'List Title' , 'textdomain' ),
						'label_block' => true,
					],
					[
						'name' => 'ic_content',
						'label' => esc_html__( 'Content', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => esc_html__( 'List Content' , 'textdomain' ),
						'show_label' => false,
					],
					[
						'name' => 'ic_sec_color',
						'label' => esc_html__( 'Background', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .bg-varient_'  => 'background: {{VALUE}}',
						]
					],
					[
						'name' => 'ic_animation_delay',
						'label' => esc_html__( 'Animation Delay', 'textdomain' ),
						'type' => \Elementor\Controls_Manager::NUMBER
					],
				],
				'default' => [
					[
						'ic_icon' => 'fas fa-circle',
						'ic_title' => esc_html__( 'Title #1', 'textdomain' ),
						'ic_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'textdomain' ),
					],
					[
						'ic_icon' => 'fas fa-circle',
						'ic_title' => esc_html__( 'Title #2', 'textdomain' ),
						'ic_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'textdomain' ),
					],
	
				],
				'title_field' => '{{{ ic_title }}}',
			]
		);
		/** Repeater Field end */
		
        $this->end_controls_section();
        //End control for content tab


        /**
         * 
         * Start control for Style tab
         */
		 //Iconbox style tab start
		$this->start_controls_section(
			'iconbox_style',
			[
				'label' => esc_html__( 'Style', 'textdomain' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		// ic Icon color
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-icon' => 'color: {{VALUE}}',
				],
			]
		);
		// ic Icon BG
		$this->add_control(
			'icon_bg',
			[
				'label' => esc_html__( 'Background', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-icon' => 'background: {{VALUE}}',
				],
				'selector' => '{{WRAPPER}} .feature-icon',
			]
		);

		// Header typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ic_header_typog',
				'selector' => '{{WRAPPER}} .ic_title',
				
			]
		);

		// counter typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ic_content_typog',
				'selector' => '{{WRAPPER}} .ic_content',
				
			]
		);

        $this->end_controls_section();
        //End control for content tab
	}

    	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$id = $this->get_id();
		

		if( $settings['ic_layout_design'] == 'style1' ):
			echo '<div class="row gy-4">';
				foreach (  $settings['icon_list'] as $key => $item ) {
					$animation_delay = ( !empty($item['ic_animation_delay']) ) ? $item['ic_animation_delay'] . 's' : '';
					echo '<div class="col-lg-4 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="'.esc_attr( $animation_delay ).'">';
					echo '<div class="feature-card-style-one bg-varient_'. $key .'">';
					if( !empty($item['ic_icon']) ){
						echo '<div class="feature-icon">';
						\Elementor\Icons_Manager::render_icon( $item['ic_icon'], [ 'aria-hidden' => 'true' ] ); 
						echo '</div>';
					}
					echo '<div class="feature-disc">';
					echo '<h5>'. saastoCore_kses($item['ic_title']) .'</h5>';
					echo '<p>'. saastoCore_kses($item['ic_content']) .'</p>';
					echo '</div>';
					echo '</div>';
					echo '</div>';
				}
			echo '</div>';

		elseif( $settings['ic_layout_design'] == 'style2' ):
			echo '<div class="icon-box-style-2">';
				foreach (  $settings['icon_list'] as $key => $item ) {
					$animation_delay = ( !empty($item['ic_animation_delay']) ) ? $item['ic_animation_delay'] . 's' : '';
					echo '<div class="col-12 feature-card-style-two wow fadeInUp" data-wow-delay="'.esc_attr( $animation_delay ).'">';
					if( !empty($item['ic_icon']) ){
						echo '<div class="feature-icon">';
						\Elementor\Icons_Manager::render_icon( $item['ic_icon'], [ 'aria-hidden' => 'true' ] ); 
						echo '</div>';
					}
					echo '<div class="feature-disc">';
					echo '<h5>'. saastoCore_kses($item['ic_title']) .'</h5>';
					echo '<p>'. saastoCore_kses($item['ic_content']) .'</p>';
					echo '</div>';
					echo '</div>';
				}
			echo '</div>';

		elseif( $settings['ic_layout_design'] == 'style3' ):
			
			echo '<div class="row gy-4">';
			foreach (  $settings['icon_list'] as $key => $item ) {
				$animation_delay = ( !empty($item['ic_animation_delay']) ) ? $item['ic_animation_delay'] . 's' : '';
				echo '<div class="col-lg-3 col-md-6 col-sm-6 wow fadeInLeft" data-wow-delay="'.esc_attr( $animation_delay ).'">';
				echo '<div class="feature-card-style-four bg-varient_'. $key .'">';
				if( !empty($item['ic_icon']) ){
					echo '<div class="feature-icon">';
					\Elementor\Icons_Manager::render_icon( $item['ic_icon'], [ 'aria-hidden' => 'true' ] ); 
					echo '</div>';
				}
				echo '<div class="feature-disc">';
				echo '<h5>'. saastoCore_kses($item['ic_title']) .'</h5>';
				echo '<p>'. saastoCore_kses($item['ic_content']) .'</p>';
				echo '</div>';
				echo '</div>';
				echo '</div>';
			}
		echo '</div>';


		// Show default style
		else:
			echo '<div class="work-features">';
				foreach (  $settings['icon_list'] as $item ) {
					$animation_delay = ( !empty($item['ic_animation_delay']) ) ? $item['ic_animation_delay'] . 's' : '';
					echo '<div class="work-feature-card wow fadeInUp" data-wow-delay="'.esc_attr( $animation_delay ).'">';
					if( !empty($item['ic_icon']) ){
						echo '<div class="feature-icon">';
						\Elementor\Icons_Manager::render_icon( $item['ic_icon'], [ 'aria-hidden' => 'true' ] ); 
						echo '</div>';
					}
					echo '<div class="feature-info">';
					echo '<h5 class="text-bright-gray ic_title">'. saastoCore_kses($item['ic_title']) .'</h5>';
					echo '<p class="ic_content">'. saastoCore_kses($item['ic_content']) .'</p>';
					echo '</div>';
					echo '</div>';
				}
			echo '</div>';

		endif;

    }
	
}

$widgets_manager->register( new Saasto_iconBox() );

