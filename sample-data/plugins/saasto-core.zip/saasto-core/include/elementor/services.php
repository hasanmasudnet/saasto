<?php
namespace SaastoCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Saasto Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Saasto_Services extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'services';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Services', 'saastocore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'saasto-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'saastocore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'saastocore' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'Saasto_layout',
            [
                'label' => esc_html__('Design Layout', 'saastocore'),
            ]
        );
        $this->add_control(
            'Saasto_design_style',
            [
                'label' => esc_html__('Select Layout', 'saastocore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'saastocore'),
                    'layout-2' => esc_html__('Layout 2', 'saastocore'),
                    'layout-3' => esc_html__('Layout 3', 'saastocore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // Service group
        $this->start_controls_section(
            'Saasto_services',
            [
                'label' => esc_html__('Services List', 'saastocore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'saastocore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'saastocore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'saastocore' ),
                    'style_2' => __( 'Style 2', 'saastocore' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'Saasto_service_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'saastocore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'image',
                'options' => [
                    'image' => esc_html__('Image', 'saastocore'),
                    'icon' => esc_html__('Icon', 'saastocore'),
                ],
            ]
        );

        $repeater->add_control(
            'Saasto_service_image',
            [
                'label' => esc_html__('Upload Icon Image', 'saastocore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'Saasto_service_icon_type' => 'image'
                ]

            ]
        );

        if (Saasto_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'Saasto_service_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'Saasto_service_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'Saasto_service_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'Saasto_service_icon_type' => 'icon'
                    ]
                ]
            );
        }
        $repeater->add_control(
            'Saasto_service_title', [
                'label' => esc_html__('Title', 'saastocore'),
                'description' => Saasto_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'saastocore'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'Saasto_service_description',
            [
                'label' => esc_html__('Description', 'saastocore'),
                'description' => Saasto_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered.',
                'label_block' => true,
            ]
        ); 

        $repeater->add_control(
            'Saasto_services_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'saastocore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'saastocore' ),
                'label_off' => esc_html__( 'No', 'saastocore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'Saasto_services_btn_text',
            [
                'label' => esc_html__('Button Text', 'saastocore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'saastocore'),
                'title' => esc_html__('Enter button text', 'saastocore'),
                'label_block' => true,
                'condition' => [
                    'Saasto_services_link_switcher' => 'yes'
                ],
            ]
        );
        $repeater->add_control(
            'Saasto_services_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'saastocore' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'Saasto_services_link_switcher' => 'yes'
                ]
            ]
        );
        $repeater->add_control(
            'Saasto_services_link',
            [
                'label' => esc_html__( 'Service Link link', 'saastocore' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'https://your-link.com', 'saastocore' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'Saasto_services_link_type' => '1',
                    'Saasto_services_link_switcher' => 'yes',
                ]
            ]
        );
        $repeater->add_control(
            'Saasto_services_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'saastocore' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => Saasto_get_all_pages(),
                'condition' => [
                    'Saasto_services_link_type' => '2',
                    'Saasto_services_link_switcher' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'Saasto_service_list',
            [
                'label' => esc_html__('Services - List', 'saastocore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'Saasto_service_title' => esc_html__('Business Stratagy', 'saastocore'),
                    ],
                    [
                        'Saasto_service_title' => esc_html__('Website Development', 'saastocore')
                    ],
                    [
                        'Saasto_service_title' => esc_html__('Marketing & Reporting', 'saastocore')
                    ]
                ],
                'title_field' => '{{{ Saasto_service_title }}}',
            ]
        );
        $this->add_responsive_control(
            'Saasto_service_align',
            [
                'label' => esc_html__( 'Alignment', 'saastocore' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'text-left' => [
                        'title' => esc_html__( 'Left', 'saastocore' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'text-center' => [
                        'title' => esc_html__( 'Center', 'saastocore' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'text-right' => [
                        'title' => esc_html__( 'Right', 'saastocore' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'toggle' => true,
                'separator' => 'before',
            ]
        );
        $this->end_controls_section();

        // Saasto_services_columns_section
        $this->start_controls_section(
            'Saasto_services_columns_section',
            [
                'label' => esc_html__('Services - Columns', 'saastocore'),
            ]
        );

        $this->add_control(
            'Saasto_col_for_desktop',
            [
                'label' => esc_html__( 'Columns for Desktop', 'saastocore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 992px', 'saastocore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    12 => esc_html__( '1 Columns', 'saastocore' ),
                    6 => esc_html__( '2 Columns', 'saastocore' ),
                    4 => esc_html__( '3 Columns', 'saastocore' ),
                    3 => esc_html__( '4 Columns', 'saastocore' ),
                    2 => esc_html__( '6 Columns', 'saastocore' ),
                    1 => esc_html__( '12 Columns', 'saastocore' ),
                ],
                'separator' => 'before',
                'default' => '4',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'Saasto_col_for_laptop',
            [
                'label' => esc_html__( 'Columns for Laptop', 'saastocore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 768px', 'saastocore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    12 => esc_html__( '1 Columns', 'saastocore' ),
                    6 => esc_html__( '2 Columns', 'saastocore' ),
                    4 => esc_html__( '3 Columns', 'saastocore' ),
                    3 => esc_html__( '4 Columns', 'saastocore' ),
                    2 => esc_html__( '6 Columns', 'saastocore' ),
                    1 => esc_html__( '12 Columns', 'saastocore' ),
                ],
                'separator' => 'before',
                'default' => '4',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'Saasto_col_for_tablet',
            [
                'label' => esc_html__( 'Columns for Tablet', 'saastocore' ),
                'description' => esc_html__( 'Screen width equal to or greater than 576px', 'saastocore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    12 => esc_html__( '1 Columns', 'saastocore' ),
                    6 => esc_html__( '2 Columns', 'saastocore' ),
                    4 => esc_html__( '3 Columns', 'saastocore' ),
                    3 => esc_html__( '4 Columns', 'saastocore' ),
                    2 => esc_html__( '6 Columns', 'saastocore' ),
                    1 => esc_html__( '12 Columns', 'saastocore' ),
                ],
                'separator' => 'before',
                'default' => '6',
                'style_transfer' => true,
            ]
        );
        $this->add_control(
            'Saasto_col_for_mobile',
            [
                'label' => esc_html__( 'Columns for Mobile', 'saastocore' ),
                'description' => esc_html__( 'Screen width less than 576px', 'saastocore' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    12 => esc_html__( '1 Columns', 'saastocore' ),
                    6 => esc_html__( '2 Columns', 'saastocore' ),
                    4 => esc_html__( '3 Columns', 'saastocore' ),
                    3 => esc_html__( '4 Columns', 'saastocore' ),
                    5 => esc_html__( '5 Columns (For Carousel Item)', 'saastocore' ),
                    2 => esc_html__( '6 Columns', 'saastocore' ),
                    1 => esc_html__( '12 Columns', 'saastocore' ),
                ],
                'separator' => 'before',
                'default' => '12',
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();

        // TAB_STYLE
        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'saastocore' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'text_transform',
            [
                'label' => __( 'Text Transform', 'saastocore' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __( 'None', 'saastocore' ),
                    'uppercase' => __( 'UPPERCASE', 'saastocore' ),
                    'lowercase' => __( 'lowercase', 'saastocore' ),
                    'capitalize' => __( 'Capitalize', 'saastocore' ),
                ],
                'selectors' => [
                    '{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

        <?php if ( $settings['Saasto_design_style']  == 'layout-2' ): 
            $this->add_render_attribute('title_args', 'class', 'sectionTitle__big');
        ?>

         <section class="cta__area">
            <div class="container">
               <div class="cta__inner">
                  <div class="row">
                    <?php foreach ($settings['Saasto_service_list'] as $key => $item) : 
                        $border = ($key == 0) ? 'cta__item-border pr-110' : '';
                        $item_sec_class = ($key == 1) ? 'pl-85' : '';
                        $btn_class = ($key == 1) ? 'saasto-btn saasto-btn-4' : 'saasto-btn saasto-btn-3';
                        // Link
                        if ('2' == $item['Saasto_services_link_type']) {
                            $link = get_permalink($item['Saasto_services_page_link']);
                            $target = '_self';
                            $rel = 'nofollow';
                        } else {
                            $link = !empty($item['Saasto_services_link']['url']) ? $item['Saasto_services_link']['url'] : '';
                            $target = !empty($item['Saasto_services_link']['is_external']) ? '_blank' : '';
                            $rel = !empty($item['Saasto_services_link']['nofollow']) ? 'nofollow' : '';
                        }
                    ?> 
                     <div class="col-xxl-6 col-xl-6 col-lg-6">
                        <div class="cta__item <?php echo esc_attr($border); ?> <?php echo esc_attr($item_sec_class); ?> pt-40 pb-15 d-sm-flex align-items-start">
                           <div class="cta__icon mr-30">
                              <span>
                               <?php if($item['Saasto_service_icon_type'] !== 'image') : ?>
                                    <?php if (!empty($item['Saasto_service_icon']) || !empty($item['Saasto_service_selected_icon']['value'])) : ?>
                                        <span class="keyFeatureBlock__icon">
                                            <?php Saasto_render_icon($item, 'Saasto_service_icon', 'Saasto_service_selected_icon'); ?>
                                        </span>
                                    <?php endif; ?>   
                                <?php else : ?>                                
                                    <?php if (!empty($item['Saasto_service_image']['url'])): ?>
                                        <span class="keyFeatureBlock__icon">    
                                        <img src="<?php echo $item['Saasto_service_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($item['Saasto_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                        </span> 
                                        <?php endif; ?> 
                                <?php endif; ?> 
                              </span>                             
                           </div>

                           <div class="cta__content">
                              <?php if (!empty($item['Saasto_service_title' ])): ?>
                              <h3 class="cta__title"><?php echo saastoCore_kses($item['Saasto_service_title' ]); ?></h3>
                              <?php endif; ?> 
                              <?php if (!empty($item['Saasto_service_description' ])): ?>
                              <p class="keyFeatureBlock__text"><?php echo saastoCore_kses($item['Saasto_service_description']); ?></p>
                              <?php endif; ?>


                            <?php if (!empty($link)) : ?>
                            <div class="sv-btn">
                                <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>" class="<?php echo esc_attr($btn_class); ?>">
                                <?php echo saastoCore_kses($item['Saasto_services_btn_text']); ?>    
                                </a>
                            </div>
                            <?php endif; ?>
                           </div>

                        </div>
                     </div>
                     <?php endforeach; ?>

                  </div>
               </div>
            </div>
         </section>

        <?php elseif ( $settings['Saasto_design_style']  == 'layout-3' ): ?>
 

        <?php else: 
            $this->add_render_attribute('title_args', 'class', 'title');
        ?>  

         <section class="features__area">
            <div class="container">
               <div class="features__inner p-relative z-index-1 white-bg">
                  <div class="row">
                    <?php foreach ($settings['Saasto_service_list'] as $key => $item) : 
                        $border_none = ($key == 2) ? '' : 'features__border-right';
                        // Link
                        if ('2' == $item['Saasto_services_link_type']) {
                            $link = get_permalink($item['Saasto_services_page_link']);
                            $target = '_self';
                            $rel = 'nofollow';
                        } else {
                            $link = !empty($item['Saasto_services_link']['url']) ? $item['Saasto_services_link']['url'] : '';
                            $target = !empty($item['Saasto_services_link']['is_external']) ? '_blank' : '';
                            $rel = !empty($item['Saasto_services_link']['nofollow']) ? 'nofollow' : '';
                        }
                    ?>
                     <div class="col-xl-<?php echo esc_attr($settings['Saasto_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['Saasto_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['Saasto_col_for_tablet']); ?> col-<?php echo esc_attr($settings['Saasto_col_for_mobile']); ?>">
                        <div class="features__item   d-sm-flex align-items-start white-bg mb-30">
                           <div class="features__icon mr-25">
                                <?php if($item['Saasto_service_icon_type'] !== 'image') : ?>
                                    <?php if (!empty($item['Saasto_service_icon']) || !empty($item['Saasto_service_selected_icon']['value'])) : ?>
                                        <div class="saasto-sv-icon">
                                            <?php Saasto_render_icon($item, 'Saasto_service_icon', 'Saasto_service_selected_icon'); ?>
                                        </div>
                                    <?php endif; ?>   
                                <?php else : ?>
                                    <div class="saasto-sv-icon">
                                        <?php if (!empty($item['Saasto_service_image']['url'])): ?>
                                        <img src="<?php echo $item['Saasto_service_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($item['Saasto_service_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                        <?php endif; ?>  
                                    </div>
                                <?php endif; ?>                                 
                           </div>
                           <div class="features__content">
                            <?php if (!empty($item['Saasto_service_title' ])): ?>
                            <h3 class="features__title">
                                <?php if ($item['Saasto_services_link_switcher'] == 'yes') : ?>
                                <a href="<?php echo esc_url($link); ?>"><?php echo saastoCore_kses($item['Saasto_service_title' ]); ?></a>
                                <?php else : ?>
                                    <?php echo saastoCore_kses($item['Saasto_service_title' ]); ?>
                                <?php endif; ?>
                            </h3>
                            <?php endif; ?> 

                            <?php if (!empty($item['Saasto_service_description' ])): ?>
                            <p><?php echo saastoCore_kses($item['Saasto_service_description']); ?></p>
                            <?php endif; ?>


                            <?php if (!empty($link)) : ?>
                            <div class="sv-btn">
                                <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>" class="link-btn">
                                <?php echo saastoCore_kses($item['Saasto_services_btn_text']); ?> <i class="fa-regular fa-arrow-right"></i></a>
                            </div>
                            <?php endif; ?>
                           </div>
                        </div>
                     </div>
                     <?php endforeach; ?>
                  </div>
               </div>
            </div>
         </section>


        <?php endif; ?>

        <?php 
    }
}

$widgets_manager->register( new Saasto_Services() );