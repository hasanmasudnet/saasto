<?php
namespace SaastoCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Saasto Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Saasto_Video_Popup extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'saasto-video-popup';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'TP Video', 'saastocore' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'saasto-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'saastocore' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'saastocore' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        // layout Panel
        $this->start_controls_section(
            'Saasto_layout',
            [
                'label' => esc_html__('Design Layout', 'saastocore'),
            ]
        );
        $this->add_control(
            'Saasto_design_style',
            [
                'label' => esc_html__('Select Layout', 'saastocore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'saastocore'),
                    'layout-2' => esc_html__('Layout 2', 'saastocore'),
                    'layout-3' => esc_html__('Layout 3', 'saastocore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // Saasto_section_title
        $this->start_controls_section(
            'Saasto_section_title',
            [
                'label' => esc_html__('Title & Content', 'saastocore'),
            ]
        );

        $this->add_control(
            'Saasto_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'saastocore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'saastocore' ),
                'label_off' => esc_html__( 'Hide', 'saastocore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'Saasto_sub_title',
            [
                'label' => esc_html__('Sub Title', 'saastocore'),
                'description' => Saasto_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Sub Title', 'saastocore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'saastocore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'Saasto_title',
            [
                'label' => esc_html__('Title', 'saastocore'),
                'description' => Saasto_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TP Title Here', 'saastocore'),
                'placeholder' => esc_html__('Type Heading Text', 'saastocore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'Saasto_desctiption',
            [
                'label' => esc_html__('Description', 'saastocore'),
                'description' => Saasto_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('TP section description here', 'saastocore'),
                'placeholder' => esc_html__('Type section description here', 'saastocore'),
            ]
        );

        $this->add_control(
            'Saasto_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'saastocore'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'saastocore'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'saastocore'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'saastocore'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'saastocore'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'saastocore'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'saastocore'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $this->add_responsive_control(
            'Saasto_align',
            [
                'label' => esc_html__('Alignment', 'saastocore'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'text-left' => [
                        'title' => esc_html__('Left', 'saastocore'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'text-center' => [
                        'title' => esc_html__('Center', 'saastocore'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'text-right' => [
                        'title' => esc_html__('Right', 'saastocore'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => false,
            ]
        );
        $this->end_controls_section();

        // Saasto_video
        $this->start_controls_section(
            'Saasto_video',
            [
                'label' => esc_html__('Video', 'saastocore'),
                'condition' => [
                    'Saasto_design_style' => 'layout-1'
                ],
            ]
        );

        $this->add_control(
            'Saasto_video_url',
            [
                'label' => esc_html__('Video', 'saastocore'),
                'type' => Controls_Manager::TEXT,
                'default' => 'https://www.youtube.com/watch?v=AjgD3CvWzS0',
                'title' => esc_html__('Video url', 'saastocore'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        // _Saasto_image
        $this->start_controls_section(
            '_Saasto_image_section',
            [
                'label' => esc_html__('Thumbnail', 'saastocore'),
            ]
        );
        $this->add_control(
            'Saasto_image',
            [
                'label' => esc_html__( 'Choose Image', 'saastocore' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'Saasto_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->add_control(
            'Saasto_image_overlap',
            [
                'label' => esc_html__('Image overlap to top?', 'saastocore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'saastocore'),
                'label_off' => esc_html__('No', 'saastocore'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );
        $this->add_responsive_control(
            'Saasto_image_height',
            [
                'label' => esc_html__( 'Image Height', 'saastocore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .saasto-overlap img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'Saasto_image_overlap_x',
            [
                'label' => esc_html__( 'Image overlap position', 'saastocore' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .saasto-overlap img' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => array(
                    'Saasto_image_overlap' => 'yes',
                ),
            ]
        );
        $this->end_controls_section();



		// TAB_STYLE
		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'saastocore' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'text_transform',
			[
				'label' => __( 'Text Transform', 'saastocore' ),
				'type' => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					'' => __( 'None', 'saastocore' ),
					'uppercase' => __( 'UPPERCASE', 'saastocore' ),
					'lowercase' => __( 'lowercase', 'saastocore' ),
					'capitalize' => __( 'Capitalize', 'saastocore' ),
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'text-transform: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

		<?php if ( $settings['Saasto_design_style']  == 'layout-2' ): 
            if ( !empty($settings['Saasto_image']['url']) ) {
                $Saasto_image = !empty($settings['Saasto_image']['id']) ? wp_get_attachment_image_url( $settings['Saasto_image']['id'], $settings['Saasto_image_size_size']) : $settings['Saasto_image']['url'];
                $Saasto_image_alt           = get_post_meta($settings["Saasto_image"]["id"], "_wp_attachment_image_alt", true);
            }

            $this->add_render_attribute('title_args', 'class', 'hero__title hero__title--big');
        ?>
        <section class="hero hero--style2">
          
        </section>

		<?php else: 
            if ( !empty($settings['Saasto_image']['url']) ) {
                $Saasto_image = !empty($settings['Saasto_image']['id']) ? wp_get_attachment_image_url( $settings['Saasto_image']['id'], $settings['Saasto_image_size_size']) : $settings['Saasto_image']['url'];
                $Saasto_image_alt           = get_post_meta($settings["Saasto_image"]["id"], "_wp_attachment_image_alt", true);
            }
            
			$this->add_render_attribute('title_args', 'class', 'hero__title hero__title--big wow animate__fadeInUp');
            $this->add_render_attribute('title_args', 'data-wow-duration', '1200ms');
            $this->add_render_attribute('title_args', 'data-wow-delay', '300ms');

		?>	

         <div class="campus__thumb w-img mb-30">

            <?php if ($settings['Saasto_image']['url'] || $settings['Saasto_image']['id']) : ?>
            <img src="<?php echo esc_url($Saasto_image); ?>" alt="<?php echo esc_attr($Saasto_image_alt); ?>">
            <?php endif; ?>

            <?php if ( !empty($settings['Saasto_video_url']) ) : ?>
            <a href="<?php echo esc_url($settings["Saasto_video_url"]); ?>" class="play-btn popup-video pulse-btn">
               <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15.5 8.13397C16.1667 8.51888 16.1667 9.48113 15.5 9.86603L2 17.6603C1.33333 18.0452 0.5 17.564 0.5 16.7942V1.20577C0.5 0.43597 1.33333 -0.0451542 2 0.339746L15.5 8.13397Z" fill="#3D6CE7"/>
               </svg>                              
            </a>
            <?php endif; ?>
         </div>

        <?php endif; ?>

        <?php 
		
	}

}

$widgets_manager->register( new Saasto_Video_Popup() );